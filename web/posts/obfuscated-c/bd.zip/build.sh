gcc \
  -std=c99 \
  -O3 -ffast-math -funroll-loops -fmerge-all-constants \
  -Wall -Wextra -Weverything -pedantic \
  -Wno-keyword-macro -Wno-cast-align \
  -o bd \
  bd.c
