// Headers
#include <stdio.h>  // printf, getc
#include <stdlib.h> // atoi, srand, rand, system
#include <time.h>   // time

// Prototypes
int main(int v, char **s)

// Keywords
#define run(allocSize,entryMethod){return 0&(!METHOD&&(v=(-STACK_OFFSET&0xFFF)<<8|v&0xFF)&&!main(entryMethod|allocSize+3,(char**)&v)\
ELIF(METHOD==entryMethod&&parameter)1|(!STACK_FRAME_DELTA&&1|(ENV|=STACK_OFFSET<<20)&&1|system("stty -icanon 2>/dev/null")\
ELIF(STACK_OFFSET/STACK_FRAME_DELTA==2)(INVOKE(void,(unsigned int),srand,((unsigned int)time(0)))))&&!main(v-1,s)
#define var(x)(*(int*)((size_t)s+(size_t)STACK_FRAME_DELTA*(size_t)((x)+3)))
#define case(x))&&(ACTIVE=1))|1&&(ACTIVE&&(ACTIVE==1||SWITCH==(x))&&(1
#define argv ((char**)((size_t)s+(size_t)(ENV>>8&0xFFF)))
#define depth (STACK_OFFSET/STACK_FRAME_DELTA-3)
#define function(x)ELIF(METHOD==x)FUNC_IMPL
#define lambda(x)ELIF(METHOD==x)LAMBDA_IMPL
#define switch(x)do SWITCH=x SWITCH_IMPL
#define for(y,x)if(x)(goto(y|x-1))
#define default ))|1&&(ACTIVE&&(1
#define elif(x)ELIF(x)IF_IMPL
#define goto(x)do main((x),s)
#define parameter (v&0xFFFF)
#define if(x)do(x)&&IF_IMPL
#define else(x)||IF_IMPL(x)
#define break )&&(ACTIVE=0
#define do )&&ACTIVE&&1|(
#define argc (ENV&0xFF)
#define with )|(
#define eof );}

// Internal shorthand
#define n(r,q)(*(r(**)q)((size_t)&s-(size_t)STACK_FRAME_DELTA))
#define LAMBDA_IMPL(x)FUNC_IMPL(x if(parameter)(goto(v-1)))
#define SWITCH_IMPL(x)do((ACTIVE=2)&&(0 x)))&&(ACTIVE=1
#define STACK_OFFSET ((int)(size_t)&v-(int)(size_t)s)
#define INVOKE(r,q,f,x)(n(void,q)=&f)&&n(int,q)x
#define FUNC_IMPL(x)((ACTIVE=1)x)|1&&(ACTIVE=1)
#define METHOD ((unsigned int)v&0xFFFF0000)
#define STACK_FRAME_DELTA (ENV>>20)
#define IF_IMPL(x)(1 x)
#define ELIF(x)||(x)&&
#define SWITCH var(-1)
#define ACTIVE var(-2)
#define ENV *(int*)s
