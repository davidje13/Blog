// Headers
#include <stdio.h>  // printf, getc
#include <stdlib.h> // atoi, srand, rand, system
#include <time.h>   // time

// Prototypes
int main(int v, char **s)

// Shorthand
#define run(allocSize,entryMethod){return 0&(!METHOD&&(v=(-STACK_OFFSET&0xFFF)<<8|v&0xFF)&&!main(entryMethod|allocSize+3,(char**)&v)\
ELIF(METHOD==entryMethod&&p)1|(!STACK_FRAME_DELTA&&1|(ENV|=STACK_OFFSET<<20)&&1|system("stty -icanon 2>/dev/null")\
ELIF(STACK_OFFSET/STACK_FRAME_DELTA==2)(N(void,(unsigned int),srand,((unsigned int)time(0)))))&&!main(v-1,s)
#define var(x)(*(int*)((size_t)s+(size_t)STACK_FRAME_DELTA*(size_t)((x)+3)))
#define argv ((char**)((size_t)s+(size_t)(ENV>>8&0xFFF)))
#define case(x))&&(ACTIVE=1))|1&&(ACTIVE&&(ACTIVE==1||SWITCH==(x))&&(1
#define n(r,q)(*(r(**)q)((size_t)&s-(size_t)STACK_FRAME_DELTA))
#define N(r,q,f,x)(n(void,q)=&f)&&n(int,q)x
#define STACK_OFFSET ((int)(size_t)&v-(int)(size_t)s)
#define METHOD ((unsigned int)v&0xFFFF0000)
#define S(x)do((ACTIVE=2)&&(0 x)))&&(ACTIVE=1
#define for(y,x)if(x)(goto(y|x-1))
#define L(x)F(x if(p)(goto(v-1)))
#define function(x)ELIF(METHOD==x)F
#define goto(x)do main((x),s)
#define F(x)((ACTIVE=1)x)|1&&(ACTIVE=1)
#define lambda(x)ELIF(METHOD==x)L
#define default ))|1&&(ACTIVE&&(1
#define switch(x)do SWITCH=x S
#define elif(x)ELIF(x)I
#define ELIF(x)||(x)&&
#define if(x)do(x)&&I
#define break )&&(ACTIVE=0
#define depth (STACK_OFFSET/STACK_FRAME_DELTA-3)
#define else(x)||I(x)
#define do )&&ACTIVE&&1|(
#define argc (ENV&0xFF)
#define p (v&0xFFFF)
#define ENV *(int*)s
#define SWITCH var(-1)
#define ACTIVE var(-2)
#define STACK_FRAME_DELTA (ENV>>20)
#define I(x)(1 x)
#define with )|(
#define eof );}
