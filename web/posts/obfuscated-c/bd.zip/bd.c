// This uses ANSI codes to colour the output.
// If your terminal does not support ANSI codes, define NO_TERM_COLS at build time

#include "lang.h"
#include "vars.h"

// Print helpers (with/without ANSI codes)
#ifdef NO_TERM_COLS
#  define put(f,m) do printf(m " ")
#  define reset_cursor
#else
#  define put(f,m) do printf(f m DEF " ")
#  define reset_cursor do printf("\x1b[%dF",height+5)
#endif

// Initialise memory and call init
run(vars, init)

function(init) (
	if (depth > vars + 1) (
		do b = size / 5 // number of rocks
		do c = size / 10 // number of walls
		do allgems = wincount * 3 + size / 20 + 1
		if (allgems + b + c + 1 > size) (
			do allgems = size / 20 + 1
		)
		do player_x = width / 2
		do player_y = height - 1
		do gems = allgems
		do dead = 0
		for (loop_init, size)
		goto(gameloop)
		if (gems > best) ( do best = gems )
		if (gems >= allgems) ( do wincount ++ )
		if (dead == -3) (
			break
		) elif (dead != -2) (
			do printf(" (best: %d) Press any key to restart.\n", best)
			do getc(stdin)
		)
		goto(init)
	) elif (argc == 3) (
		do wincount = 0
		do best = 0
		do width = atoi(argv[1])
		do height = atoi(argv[2])
		do size = width * height
		if (size > 1000) (
			do printf("\nLarge grid, continue? (y/n) ")
			if (getc(stdin) != 'y') (
				do printf("\nTry 20x20.\n")
				break
			)
		)
		goto(init with size)
		do printf(" Bye.\n")
	) else (
		do printf("Try:\n\t%s 20 20\n\n", argv[0])
	)
)

function(gameloop) (
	do printf("\n\n")
	if (parameter) (
		do map_at_player_offset(0, 0) = empty
		switch (parameter) (
			case (1) do player_y -- break
			case (2) do player_x -- break
			case (3) do player_y ++ break
			case (4) do player_x ++ break
		)
		switch (map_at_player_offset(0, 0)) (
			case (gem)
				do gems ++
				break
			case (rock)
				do map_at_player_offset((parameter == 4) * 2 - 1, 0) = rock
				break
		)
		do map_at_player_offset(0, 0) = player
		goto(gravity)
	)

	do b = ( // can move left?
		player_x > 0 &&
		(
			map_at_player_offset(-1, 0) is soft ||
			(
				map_at_player_offset(-1, 0) == rock &&
				player_x > 1 &&
				map_at_player_offset(-2, 0) == empty
			)
		)
	)
	do c = ( // can move right?
		player_x < width - 1 &&
		(
			map_at_player_offset(1, 0) is soft ||
			(
				map_at_player_offset(1, 0) == rock &&
				player_x < width - 2 &&
				map_at_player_offset(2, 0) == empty
			)
		)
	)

	if (!dead) (
		if (
			!b &&
			!c &&
			!(player_y > 0 && map_at_player_offset(0, -1) is soft) &&
			!(player_y < height - 1 && map_at_player_offset(0, 1) is soft)
		) (
			do dead = 2
		) elif (gems == allgems) (
			do dead = -1
		)
	)

	goto(drawmap)

	switch (dead) (
		case (-1) do printf("All %d Gems Collected! ", gems) break
		case (2) do printf("Stuck!   Final gems: %d", gems) break
		case (1) do printf("Crushed! Final gems: %d", gems) break
		default
			do printf("%d / %d gems (past best: %d). WASD: move, R: reset, Q: quit.\n", gems, allgems, best)
			do a = 0
			switch (getc(stdin)) (
				case (27)
					if (getc(stdin) == 91) (
						switch (getc(stdin)) (
							case (65) do a = 1 break
							case (68) do a = 2 break
							case (66) do a = 3 break
							case (67) do a = 4 break
						)
					)
					break
				case (239)
					if (getc(stdin) == 156) (
						switch (getc(stdin)) (
							case (128) do a = 1 break
							case (130) do a = 2 break
							case (129) do a = 3 break
							case (131) do a = 4 break
						)
					)
					break
				case ('w') do a = 1 break
				case ('a') do a = 2 break
				case ('s') do a = 3 break
				case ('d') do a = 4 break
				case ('r') do a = -1 break
				case ('q') do a = -2 break
			)
			switch (a) (
				case (-1) do dead = -2 do a = -1 do printf("\rReset.") break
				case (-2) do dead = -3 do a = -1 do printf("\rQuit.") break
				case (1) do a = 1 * (player_y > 0 && map_at_player_offset(0, -1) is soft) break
				case (2) do a = 2 * b break
				case (3) do a = 3 * (player_y < height - 1 && map_at_player_offset(0, 1) is soft) break
				case (4) do a = 4 * c break
				default do a = 0 break
			)
			if (a >= 0) (
				reset_cursor
				goto(gameloop with a)
			)
			break
	)
)

function(drawmap) (
	do printf(".-")
	for (loop_drawx2, width)
	do printf(".\n")
	for (loop_drawy, height)
	do printf("'-")
	for (loop_drawx2, width)
	do printf("'\n")
)

function(gravity) (
	for (loop_gravx, width)
)

lambda(loop_gravx) (
	do a = parameter
	for (loop_gravy, height - 1)
)

lambda(loop_gravy) (
	do b = mapcoord(a, parameter)
	if (var(b) == rock && var(b + width) == empty) (
		for (loop_gravy2, height - parameter - 1)
	)
)
lambda(loop_gravy2) (
	switch (var(b + width)) (
		case (empty)
			do var(b) = empty
			do var(b + width) = rock
			do b += width
			break
		case (player)
			do dead = 1
			break
	)
)

lambda(loop_drawy) (
	do a = height - parameter - 1
	do printf("| ")
	for (loop_drawx, width)
	do printf("|\n")
)

lambda(loop_drawx) (
	switch (map_at(width - parameter - 1, a)) (
		case (player)
			switch (dead) (
				case (-1) put(T_ME, ":D") break
				case (2) put(T_ME, ":S") break
				case (1) put(T_ME, ":(") break
				default put(T_ME, ":)") break
			)
			break
		case (empty) do printf("   ") break
		case (soil) do printf("~~ ") break
		case (gem) put(T_GEM, "<>") break
		case (rock) put(T_ROCK, "@@") break
		case (wall) do printf("XX ") break
	)
)

lambda(loop_drawx2) (
	do printf("---")
)

lambda(loop_init) (
	if (mapcoord(player_x, player_y) == mapindex(parameter)) (
		do var(mapindex(parameter)) = player
		do a = 1
	) else (
		do d = rand() % (parameter + a)
		if (d < b) (
			do var(mapindex(parameter)) = rock
			do b --
		) elif (d < b + c) (
			do var(mapindex(parameter)) = wall
			do c --
		) elif (d < b + c + gems) (
			do var(mapindex(parameter)) = gem
			do gems --
		) else (
			do var(mapindex(parameter)) = soil
		)
	)
)

eof
