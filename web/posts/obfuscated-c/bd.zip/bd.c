// This uses ANSI codes to colour the output.
// If your terminal does not support ANSI codes, define NO_TERM_COLS at build time

#include "lang.h"
#include "vars.h"

// Print helpers (with/without ANSI codes)
#ifdef NO_TERM_COLS
#  define put(f,m) do printf(m " ")
#  define reset_cursor
#else
#  define put(f,m) do printf(f m DEF " ")
#  define reset_cursor do printf("\x1b[%dF",height+5)
#endif

// Initialise memory and call init
run(vars, init)

function(init) (
	if (depth > vars + 1) (
		if (scratch) (
			do wincount = 0
			do best = 0
		)
		do storage2 = size / 5
		do storage3 = size / 10
		do allgems = wincount * 3 + size / 20 + 1
		if (allgems + storage2 + storage3 + 1 > size) (
			do allgems = size / 20 + 1
		)
		do player_x = width / 2
		do player_y = height - 1
		do storage = 0
		do gems = allgems
		do dead = 0
		for (loop_init, size)
		goto(gameloop)
		if (gems > best) (
			do best = gems
		)
		if (gems >= allgems) (
			do wincount ++
		)
		if (dead == -3) (
			break
		) elif (dead != -2) (
			do printf(" (best: %d) Press any key to restart.\n", best)
			do getc(stdin)
		)
		do scratch = 0
		goto(init)
	) elif (argc == 3) (
		do width = atoi(argv[1])
		do height = atoi(argv[2])
		do size = width * height
		do scratch = 1
		if (size > 1000) (
			do printf("\nLarge grid, continue? (y/n) ")
			if (getc(stdin) != 'y') (
				do printf("\nTry 20x20.\n")
				break
			)
		)
		goto(init with size)
		do printf(" Bye.\n")
	) else (
		do printf("Try:\n\t%s 20 20\n\n", argv[0])
	)
)

function(gameloop) (
	do printf("\n\n")
	if (p) (
		do map_at_player_offset(0, 0) = empty
		switch (p) (
			case (1)
				do player_y --
				break
			case (2)
				do player_x --
				break
			case (3)
				do player_y ++
				break
			case (4)
				do player_x ++
				break
		)
		switch (map_at_player_offset(0, 0)) (
			case (gem)
				do gems ++
				break
			case (rock)
				do map_at_player_offset((p == 4) * 2 - 1, 0) = rock
				break
		)
		do map_at_player_offset(0, 0) = player
		goto(gravity)
	)

	do storage2 = (
		player_x > 0 &&
		(
			map_at_player_offset(-1, 0) is soft ||
			(
				map_at_player_offset(-1, 0) == rock &&
				player_x > 1 &&
				map_at_player_offset(-2, 0) == empty
			)
		)
	)
	do storage3 = (
		player_x < width - 1 &&
		(
			map_at_player_offset(1, 0) is soft ||
			(
				map_at_player_offset(1, 0) == rock &&
				player_x < width - 2 &&
				map_at_player_offset(2, 0) == empty
			)
		)
	)

	if (!dead) (
		if (
			!storage2 &&
			!storage3 &&
			!(player_y > 0 && map_at_player_offset(0, -1) is soft) &&
			!(player_y < height - 1 && map_at_player_offset(0, 1) is soft)
		) (
			do dead = 2
		) elif (gems == allgems) (
			do dead = -1
		)
	)

	goto(drawmap)

	switch (dead) (
		case (-1)
			do printf("All %d Gems Collected! ", gems)
			break
		case (2)
			do printf("Stuck!   Final gems: %d", gems)
			break
		case (1)
			do printf("Crushed! Final gems: %d", gems)
			break
		default
			do printf("%d / %d gems (past best: %d). WASD: move, R: reset, Q: quit.\n", gems, allgems, best)
			do storage = 0
			switch (getc(stdin)) (
				case (27)
					if (getc(stdin) == 91) (
						switch (getc(stdin)) (
							case (65)
								do storage = 1
								break
							case (68)
								do storage = 2
								break
							case (66)
								do storage = 3
								break
							case (67)
								do storage = 4
								break
						)
					)
					break
				case (239)
					if (getc(stdin) == 156) (
						switch (getc(stdin)) (
							case (128)
								do storage = 1
								break
							case (130)
								do storage = 2
								break
							case (129)
								do storage = 3
								break
							case (131)
								do storage = 4
								break
						)
					)
					break
				case ('w')
					do storage = 1
					break
				case ('a')
					do storage = 2
					break
				case ('s')
					do storage = 3
					break
				case ('d')
					do storage = 4
					break
				case ('r')
					do storage = -1
					break
				case ('q')
					do storage = -2
					break
			)
			switch (storage) (
				case (-1)
					do dead = -2
					do printf("\rReset.")
					break
				case (-2)
					do dead = -3
					do printf("\rQuit.")
					break
				case (1)
					reset_cursor
					goto(gameloop with 1 * (player_y > 0 && map_at_player_offset(0, -1) is soft))
					break
				case (2)
					reset_cursor
					goto(gameloop with 2 * storage2)
					break
				case (3)
					reset_cursor
					goto(gameloop with 3 * (player_y < height - 1 && map_at_player_offset(0, 1) is soft))
					break
				case (4)
					reset_cursor
					goto(gameloop with 4 * storage3)
					break
				default
					reset_cursor
					goto(gameloop)
					break
			)
			break
	)
)

function(drawmap) (
	do printf(".-")
	for (loop_drawx2, width)
	do printf(".\n")
	for (loop_drawy, height)
	do printf("'-")
	for (loop_drawx2, width)
	do printf("'\n")
)

function(gravity) (
	for (loop_gravx, width)
)

lambda(loop_gravx) (
	do storage = p
	for (loop_gravy, height - 1)
)

lambda(loop_gravy) (
	do storage2 = mapcoord(storage, p)
	if (var(storage2) == rock && var(storage2 + width) == empty) (
		for (loop_gravy2, height - p - 1)
	)
)
lambda(loop_gravy2) (
	switch (var(storage2 + width)) (
		case (empty)
			do var(storage2) = empty
			do var(storage2 + width) = rock
			do storage2 += width
			break
		case (player)
			do dead = 1
			break
	)
)

lambda(loop_drawy) (
	do storage = height - p - 1
	do printf("| ")
	for (loop_drawx, width)
	do printf("|\n")
)

lambda(loop_drawx) (
	switch (map_at(width - p - 1, storage)) (
		case (player)
			switch (dead) (
				case (-1)
					put(T_ME, ":D")
					break
				case (2)
					put(T_ME, ":S")
					break
				case (1)
					put(T_ME, ":(")
					break
				default
					put(T_ME, ":)")
					break
			)
			break
		case (empty)
			do printf("   ")
			break
		case (soil)
			do printf("~~ ")
			break
		case (gem)
			put(T_GEM, "<>")
			break
		case (rock)
			put(T_ROCK, "@@")
			break
		case (wall)
			do printf("XX ")
			break
	)
)

lambda(loop_drawx2) (
	do printf("---")
)

lambda(loop_init) (
	if (mapcoord(player_x, player_y) == mapindex(p)) (
		do var(mapindex(p)) = player
		do storage = 1
	) else (
		do scratch = rand() % (p + storage)
		if (scratch < storage2) (
			do var(mapindex(p)) = rock
			do storage2 --
		) elif (scratch < storage2 + storage3) (
			do var(mapindex(p)) = wall
			do storage3 --
		) elif (scratch < storage2 + storage3 + gems) (
			do var(mapindex(p)) = gem
			do gems --
		) else (
			do var(mapindex(p)) = soil
		)
	)
)

eof
