// Constants
#define player 0
#define empty  1
#define soil   2
#define gem    3
#define rock   4
#define wall   5

#define T_ME   "\x1b[33;1m"
#define T_GEM  "\x1b[35;1m"
#define T_ROCK "\x1b[31m"
#define DEF    "\x1b[0m"

// Variables
#define size     var(0)
#define width    var(1)
#define height   var(2)
#define storage  var(3)
#define storage2 var(4)
#define storage3 var(5)
#define scratch  var(6)
#define player_x var(7)
#define player_y var(8)
#define allgems  var(9)
#define gems     var(10)
#define best     var(11)
#define wincount var(12)
#define dead     var(13)
#define vars     14

// Helpers
#define mapindex(x)               (vars+(x))
#define mapcoord(x,y)             (vars+(y)*width+(x))
#define map_at(x,y)               var(mapcoord(x,y))
#define map_at_player_offset(x,y) map_at(player_x+(x),player_y+(y))
#define is
#define soft <rock

// Pseudo-enum
#define init        0x010000
#define gameloop    0x020000
#define drawmap     0x030000
#define gravity     0x040000
#define loop_init   0x100000
#define loop_drawy  0x200000
#define loop_drawx  0x300000
#define loop_drawx2 0x400000
#define loop_gravx  0x500000
#define loop_gravy  0x600000
#define loop_gravy2 0x700000
