<?php session_start();
include('s_layout.php');
$GSA='masked@example.com';$GSC=' bgcolor="#CCDDFF" text="#666666" link="#666699" vlink="#666699" alink="#996699"';
if(!file_exists($GLOBALS['above'].'s_info.txt')){print('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><title>I appologise for the inconvenience</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head><body'.$GSC.'>I appologise for the inconvenience<br><br>One of the web files could not be found. If this problem persists, please contact me at the following address:<br><br><a href="mailto:'.$GSA.'">'.$GSA.'</a></body></html>');die;}
$info=file($GLOBALS['above'].'s_info.txt');
list($GLOBALS['Name'],$GLOBALS['Teach'],$GLOBALS['Banr'],
$GLOBALS['Rgt'],$GLOBALS['Mail'],$GLOBALS['Tel'],$GLOBALS['Locn'])=explode(':�:',$info[0]);

$GLOBALS['imgext']=array('gif','png','jpg','jpeg','tif','tiff','bmp','dib','rle','wbmp','wbm','psd','tga');

function Complete($page){
 $fexist=file_exists($GLOBALS['above'].$page.'.txt');

 $teach=0;if(isset($_SESSION['Edit']))if($_SESSION['Edit']=='Y')$teach=1;
 $edt=0;if(isset($_GET['E'])&&$fexist&&$teach)if($_GET['E']=='Y')$edt=1;
 if(isset($_GET['SSE'])&&$fexist&&$teach)if($_GET['SSE']=='Y')$edt=3;
 $strteach='';

#LOAD FILE
 $fl=0;$sty=0;
 if($fexist){
  $_SESSION['lsp']=$page;
  $fl=file($GLOBALS['above'].$page.'.txt');
  $sty=substr($fl[0],0,strpos($fl[0],':�:'));

#SAVE CHANGES / PREVIEW
  if($edt==1){
   if(isset($_GET['S']))if(isset($_POST['vd']))if($_GET['S']=='Y'){
    $do='';if(isset($_POST['do']))$do=$_POST['do'];if(isset($_POST['doDOM']))if($_POST['doDOM']!='')$do=$_POST['doDOM'];
    if($sty==0){#TEXT
     if($_POST['vd']=='0'){
      $fl[0]=stripslashes($_POST['ln_00']).Chr(10);
      $fl[1]=stripslashes($_POST['ln_01']).Chr(10);
     }else{
      $btext='';$bsize='';
      if(isset($_POST['btext'])){
       $btext=stripslashes($_POST['btext']);
       $bsize=$_POST['bsize'];
      }
      $fl=array($sty.':�:'.ToSave($btext).':�:'.$bsize.':�:'.Chr(10),ToSave(stripslashes($_POST['cont'])).':�:'.$_POST['ibold'].':�:'.Chr(10));
     }
    }else{#LIST
     if($_POST['vd']=='0'){
      $fl[0]=stripslashes($_POST['ln_00']).Chr(10);
      $fl[1]=stripslashes($_POST['ln_01']).Chr(10);
      $fl[5]=stripslashes($_POST['ln_05']).Chr(10);
     }else{
      $btext='';$bsize='';
      if(isset($_POST['btext'])){
       $btext=stripslashes($_POST['btext']);
       $bsize=$_POST['bsize'];
      }
      $fl[0]=$sty.':�:'.ToSave($btext).':�:'.$bsize.':�:'.Chr(10);
      $fl[1]=ToSave(stripslashes($_POST['head'])).':�:'.ToSave(stripslashes($_POST['foot'])).':�:'.Chr(10);

      $oldNum=$_POST['nE'];$ar=array();
      $vls=substr($fl[2],0,strpos($fl[2],':�:'));
      for($i=0;$i<$oldNum;$i++)#FILL
       if($_POST['t'.$i]=='2')$ar[$i]='2:�:'.ToSave(stripslashes($_POST['c'.$i]));
       else{$ar[$i]=(($_POST['f'.$i]=='Y')?'0':'1');for($n=0;$n<$vls;$n++)$ar[$i]=$ar[$i].':�:'.ToSave(stripslashes($_POST['i'.$n.'_'.$i]));}
      if(isset($_POST['LEB'])){#ADD BASE
       if($_POST['LEB']=='Add heading')$ar[$oldNum]='2:�:';
       else{$ar[$oldNum]='1';for($n=0;$n<$vls;$n++)$ar[$oldNum]=$ar[$oldNum].':�:';}
      }elseif(isset($_POST['LET'])){#ADD TOP
       for($n=$oldNum;$n>0;$n--)$ar[$n]=$ar[$n-1];
       if($_POST['LET']=='Add heading')$ar[0]='2:�:';
       else{$ar[0]='1';for($n=0;$n<$vls;$n++)$ar[0]=$ar[0].':�:';}
      }elseif($do==''){
       for($i=0;$i<$oldNum;$i++)
        if(isset($_POST['Do'.$i])){
         if($_POST['Do'.$i]=='Delete')unset($ar[$i]);#DELETE
         elseif($_POST['Do'.$i]=='Move up'&&$i>0){#MOVE
          $tmp=$ar[$i];$ar[$i]=$ar[$i-1];$ar[$i-1]=$tmp;
         }elseif($_POST['Do'.$i]=='Move down'&&$i<$oldNum-1){
          $tmp=$ar[$i];$ar[$i]=$ar[$i+1];$ar[$i+1]=$tmp;
      } }}
      $fl[5]=sizeof($ar).':�:'.implode(':�:',$ar).':�:'.Chr(10);#CONVERT
    }}
    if($do=='Save'){$fp=fopen($GLOBALS['above'].$page.'.txt','wb');fwrite($fp,implode('',$fl));fclose($fp);$edt=0;}elseif($do=='Preview')$edt=2;
  }}elseif($edt==3){
   $do='';if(isset($_POST['do']))$do=$_POST['do'];if(isset($_POST['doDOM']))if($_POST['doDOM']!='')$do=$_POST['doDOM'];
   if($do=='Save'){
    #SAVE GENERAL
    $ln1[0]=$GLOBALS['Name'];
    $ln1[1]=stripslashes($_POST['tname']);
    $ln1[2]=stripslashes($_POST['qual']);
    $ln1[3]=stripslashes($_POST['slog']);
    $ln1[4]=stripslashes(str_replace('<','&lt;',str_replace('>','&gt;',str_replace('[','&op;',str_replace(']','&cl;',$_POST['mail'])))));
    $ln1[5]=stripslashes($_POST['tel']);
    $ln1[6]=stripslashes($_POST['locn']);
    $fp=fopen($GLOBALS['above'].'s_info.txt','wb');
    fwrite($fp,implode(':�:',$ln1).':�:');
    fclose($fp);

    list(,$GLOBALS['Teach'],$GLOBALS['Banr'],$GLOBALS['Rgt'],$GLOBALS['Mail'],$GLOBALS['Tel'],$GLOBALS['Locn'])=$ln1;
    $edt=0;
 }}}

#TOOL
 if($teach){
  setcookie('noDelay',1,time()+60*60*24*365);
  $strteach='<tr><td colspan="3" class="TDtool"><div id="tool"><table width="100%" height="30" border="0" cellpadding="0" cellspacing="0"><tr><td class="TDtooll"></td>';
  switch($edt){
  case 0:$strteach=$strteach.'<td width="1"><input type="submit" value="Edit this page"'.($fexist?'':' disabled').' title="Click to change this page" onClick="document.location.href=\'?E=Y\'" /></td><td width="5"></td><td><input type="submit" value="Change details" title="Click to change your business details" onClick="document.location.href=\'?SSE=Y\'" /></td>';break;
  case 1:$strteach=$strteach.'<td width="1"><input type="submit" value="Preview" title="Click to preview this page" onClick="document.fm.doDOM.value=\'Preview\';document.fm.submit()" /></td><td width="5"></td><td width="1"><input type="submit" name="do" value="Save" title="Click to save your changes and return to the page" onClick="document.fm.doDOM.value=\'Save\';document.fm.submit()" /></td><td width="5"></td><td><input type="submit" value="Cancel" title="Click to return to the page without saving your changes" onClick="if(confirm(\'This will not save your changes. Are you sure you want to cancel?\'))document.location.href=\'?E=N\'" /></td>';break;
  case 2:$strteach=$strteach.'<td width="1"><div style="display:none"><form name="smm" action="?E=Y&S=Y" method="post"><input type="hidden" name="doDOM" value="" /><input type="hidden" name="vd" value="0" /><input type="hidden" name="ln_00" value="'.ToTextSimp(substr($fl[0],0,strlen($fl[0])-1)).'" /><input type="hidden" name="ln_01" value="'.ToTextSimp(substr($fl[1],0,strlen($fl[1])-1)).'" />'.(isset($fl[5])?('<input type="hidden" name="ln_05" value="'.ToTextSimp(substr($fl[5],0,strlen($fl[5])-1)).'" />'):'').'</form></div><input type="submit" name="do" value="Continue editing" title="Click to continue editing this page" onClick="document.smm.submit()" /></td><td width="5"></td><td width="1"><input type="submit" name="do" value="Save" title="Click to save your changes" onClick="document.smm.doDOM.value=\'Save\';document.smm.submit()" /></td><td width="5"></td><td><input type="submit" value="Cancel" title="Click to return to the page without saving your changes" onClick="if(confirm(\'This will not save your changes. Are you sure you want to cancel?\'))document.location.href=\'?E=N\';return false" /></td>';break;
  case 3:$strteach=$strteach.'<td width="1"><input type="submit" name="do" value="Save" title="Click to save your changes" onClick="document.fm.submit()" /></td><td width="5"></td><td><input type="submit" value="Cancel" title="Click to return without saving your changes" onClick="if(confirm(\'This will not save your changes. Are you sure you want to cancel?\'))document.location.href=\'?SSE=N\'" /></td>';break;
  }
  $strteach=$strteach.'<td width="1"><input type="submit" value="Help" title="Click to see general help" onClick="t=window.open(\'admin/help.htm\',\'help\',\'width=500,height=400,scrollbars=yes,resizable=yes\');t.focus();" /></td><td width="5"></td>';
  if($edt==0)$strteach=$strteach.'<td width="1"><input type="submit" value="Log out" title="Click to log out" onClick="document.location.href=\'admin\'" /></td><td width="5"></td>';
  else $strteach=$strteach.'<td width="1"><input type="submit" value="Log out" title="Click to log out. Note, this will NOT save your changes" onClick="if(confirm(\'Logging out now will not save your changes. Are you sure you want to log out?\'))document.location.href=\'admin\'" /></td><td width="5"></td>';
  $strteach=$strteach.'</table></div></td></tr>';
 }

#MOD 1:
 $strtop='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html lang="en"><head><title>'.$GLOBALS['Name'].'</title><meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1"><link href="StyleS.css" rel="stylesheet" media="screen" type="text/css"/><link href="StyleP.css" rel="stylesheet" media="print" type="text/css"/><script language="JavaScript" type="text/javascript"><!--
function MM_reloadPage(I){if(I)with(navigator){if(appName=="Netscape"&&parseInt(appVersion)==4){document.MM_pgW=innerWidth;document.MM_pgH=innerHeight;onresize=MM_reloadPage}}else if(innerWidth!=document.MM_pgW||innerHeight!=document.MM_pgH)location.reload()}MM_reloadPage(true)//--></script></head><body onload="LA()" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0"><script language="JavaScript" type="text/javascript"><!--
MAa=new Array("Images/Buttons/Home","Images/Buttons/Guid","Images/Buttons/Even","Images/Buttons/Clas","Images/Buttons/Cont","Images/Buttons/Link");MAb=new Array("gif","gif","gif","gif","gif","gif");MAc=new Array(0,0,0,0,0,0);
function LA(){MI=new Array();for(i=0;i<6;i++){MI[i]=new Array();for(n=0;n<5;n++){MI[i][n]=new Image;MI[i][n].src=MAa[i]+""+n+"."+MAb[i]}}}

function RO(ind){if(MAc[ind]==0)setTimeout("ROB("+ind+",1)",100);MAc[ind]=1}
function ROB(ind,pos){eval("document.Lnk"+ind+".src='"+MAa[ind]+""+pos+"."+MAb[ind]+"'");if(pos<4)setTimeout("ROB("+ind+","+(pos+1)+")",100)}
function RU(ind){if(MAc[ind]==1)setTimeout("RUB("+ind+",3)",100);MAc[ind]=0}
function RUB(ind,pos){eval("document.Lnk"+ind+".src='"+MAa[ind]+""+pos+"."+MAb[ind]+"'");if(pos>0)setTimeout("RUB("+ind+","+(pos-1)+")",100)}//--></script><table width="100%" height="100%" rows="3" cols="1" border="0" cellpadding="0" cellspacing="0">';
 $str='<tr><td height="80"><div id="Banr"><div id="BL"><table height="100%" border="0" cellpadding="0" cellspacing="0" class="Ban"><tr><td align="left" valign="middle"><a href="mailto:'.ToText(ToCodeBasic($GLOBALS['Mail'],'','banLink',$edt)).'" class="BanLnk">'.ToCodeBasic($GLOBALS['Mail'],'','banLink',$edt).'</a><br>call: '.ToCodeBasic($GLOBALS['Tel'],'','banLink',$edt).'<br>'.ToCodeBasic($GLOBALS['Locn']).'</td></tr></table></div><div id="BR"><table height="100%" border="0" cellpadding="0" cellspacing="0" class="Ban"><tr><td align="right" valign="middle">'.ToCodeBasic($GLOBALS['Rgt'],'','banLink',$edt).'</td></tr></table></div><img src="Images/Spacer.gif" width="1" height="5"><br><img src="Images/Banner1.gif"><img src="Images/Title.gif"><img src="Images/Banner2.gif"><br><span class="Diploma">'.ToCodeBasic($GLOBALS['Banr'],'','banLink',$edt).'</span></div></td></tr><tr><td height="20"><div id="Trns"></div></td></tr><tr><td><table width="100%" height="100%" rows="1" cols="3" border="0" cellpadding="0" cellspacing="0"><tr><td width="130"><div id="Mnu1"><table width="100%" height="100%" rows="7" cols="1" border="0" cellpadding="0" cellspacing="0"><tr><td></td></tr>';
 $str=$str.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'index.php\'':'index.php').'" onmouseover="window.status=\'Go back to the main page\';RO(0);return true;" onmouseout="window.status=\'\';RU(0);return true;"><img name="Lnk0" width="100" height="100" src="Images/Buttons/Home0.gif" alt="Home" border="0"></a></td></tr><tr><td height="10"></td></tr>';
 $str=$str.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'Guidance.php\'':'Guidance.php').'" onmouseover="window.status=\'View helpful information for getting started with Yoga\';RO(1);return true;" onmouseout="window.status=\'\';RU(1);return true;"><img name="Lnk1" width="100" height="100" src="Images/Buttons/Guid0.gif" alt="Guidance" border="0"></a></td></tr><tr><td height="10"></td></tr>';
 $str=$str.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'Occasions.php\'':'Occasions.php').'" onmouseover="window.status=\'View past occasions involving existing classes\';RO(2);return true;" onmouseout="window.status=\'\';RU(2);return true;"><img name="Lnk2" width="100" height="100" src="Images/Buttons/Even0.gif" alt="Occasions" border="0"></a></td></tr>';
 $str=$str.'<tr><td></td></tr></table></div></td><td><div id="Cont"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" class="ContTbl"><tr><td width="5%"></td><td align="center" valign="middle">';

 $toend='</td><td width="5%"></td></tr></table></div></td><td width="130"><div id="Mnu2"><table width="100%" height="100%" rows="7" cols="1" border="0" cellpadding="0" cellspacing="0"><tr><td></td></tr>';
 $toend=$toend.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'Classss.php\'':'Classes.php').'" onmouseover="window.status=\'View the current classes in the Telford area\';RO(3);return true;" onmouseout="window.status=\'\';RU(3);return true;"><img name="Lnk3" width="100" height="100" src="Images/Buttons/Clas0.gif" alt="Classes" border="0"></a></td></tr><tr><td height="10"></td></tr>';
 $toend=$toend.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'Contacts.php\'':'Contacts.php').'" onmouseover="window.status=\'View contact information for further enquiries\';RO(4);return true;" onmouseout="window.status=\'\';RU(4);return true;"><img name="Lnk4" width="100" height="100" src="Images/Buttons/Cont0.gif" alt="Contacts" border="0"></a></td></tr><tr><td height="10"></td></tr>';
 $toend=$toend.'<tr><td height="100" align="center" valign="middle"><a href="'.($edt?'javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\'Links.php\'':'Links.php').'" onmouseover="window.status=\'View a list of Yoga related sites\';RO(5);return true;" onmouseout="window.status=\'\';RU(5);return true;"><img name="Lnk5" width="100" height="100" src="Images/Buttons/Link0.gif" alt="Links" border="0"></a></td></tr>';
 $toend=$toend.'<tr><td></td></tr></table></div></td></tr></table></td></tr></table><script language="JavaScript" type="text/javascript"><!--
if(document.all)document.body.scroll="no";
//--></script></body></html>';
#MOD 2:

#404
 if(!$fexist){print($strtop.$strteach.$str.'I appologise for the inconvenience<br><br>The page you requested appears to be damaged. If this problem persists, please contact me at the following address:<br><br><a href="mailto:'.$GLOBALS['Mail'].'" onMouseOver="return MO(\'Click to e-mail me\')" onMouseOut="return MO()">'.$GLOBALS['Mail'].'</a>'.$toend);die;}

#EDIT
 if($edt==3){
  #TOP BAR (GENERAL DETAILS)
  $str=$str.'<form name="fm" method="post" action="?SSE=Y&S=Y"><span style="font-size:large">Details for '.$GLOBALS['Name'].':</span><br><br><table border="0" cellpadding="0" cellspacing="0"><tr><td>Business name:</td><td width="5"></td><td><b>'.$GLOBALS['Name'].'</b></td></tr><tr><td>Your name:</td><td></td><td><input type="text" name="tname" size="30" value="'.ToTextSimp($GLOBALS['Teach']).'" /></b></td></tr><tr><td>Your email address:</td><td></td><td><input type="text" name="mail" size="30" value="'.ToTextSimp(eregi_replace('&lt;','<',eregi_replace('&gt;','>',eregi_replace('&op;','[',eregi_replace('&cl;',']',$GLOBALS['Mail']))))).'" /></b></td></tr><tr><td>Your telephone number:</td><td></td><td><input type="text" name="tel" size="30" value="'.ToTextSimp($GLOBALS['Tel']).'" /></b></td></tr><tr><td>Your area:</td><td></td><td><input type="text" name="locn" size="30" value="'.ToTextSimp($GLOBALS['Locn']).'" /></b></td></tr><tr><td>Your top qualifications:</td><td></td><td><input type="text" name="qual" size="30" value="'.ToTextSimp($GLOBALS['Banr']).'" /></b></td></tr><tr><td>"slogan":</td><td></td><td><input type="text" name="slog" size="30" value="'.ToTextSimp($GLOBALS['Rgt']).'" /></b></td></tr></table><br><input type="submit" title="Click to save your changes" name="do" value="Save" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Cancel" title="Click to return without saving your changes" onClick="if(confirm(\'This will not save your changes. Are you sure you want to cancel?\'))document.location.href=\'?SSE=N\';return false" /></form>';
  print $strtop.$strteach.$str.$toend;die;
 }elseif($edt==1){
  #PAGES
  $bn=explode(':�:',$fl[0]);
  $str=$str.'<a name="top"></a><form name="fm" method="post" action="?E=Y&S=Y"><input type="hidden" name="doDOM" value="" /><input type="hidden" name="vd" value="1" /><b>You are now editing '.(($page=='index')?'the front page':str_replace('_',' > ',$page)).'</b><br><br>';
  if($page=='index')$str=$str.'<b>Banner:</b><br><textarea name="btext" rows="2" style="width:75%">'.ToText($bn[1]).'</textarea><br><input type="radio" name="bsize" value="medium" id="s0"'.(($bn[2]=='medium')?' checked="checked"':'').' /><label for="s0">Normal</label>&nbsp;&nbsp;<input type="radio" name="bsize" value="large" id="s1"'.(($bn[2]=='large')?' checked="checked"':'').' /><label for="s1">Large</label>&nbsp;&nbsp;<input type="radio" name="bsize" value="x-large" id="s2"'.(($bn[2]=='x-large')?' checked="checked"':'').' /><label for="s2">Very big</label>&nbsp;&nbsp;<input type="radio" name="bsize" value="300%" id="s3"'.(($bn[2]=='300%')?' checked="checked"':'').' /><label for="s3">Huge</label><br><br>';
  if($sty==0){#TEXT
   $bnr=explode(':�:',$fl[1]);$str=$str.'<b>Content:</b><br><input type="checkbox" name="ibold" value="1"'.(($bnr[1]=='1')?' checked="checked"':'').' id="ib0" /><label for="ib0">All bold by default</label><br><textarea name="cont" rows="20" style="width:75%">'.ToText($bnr[0]).'</textarea><br>';
  }else{#LIST
   $hf=explode(':�:',$fl[1]);
   $nms=explode(':�:',$fl[2]);
   $fmat=substr($fl[4],0,strpos($fl[4],':�:'));
   $cont=explode(':�:',$fl[5]);
   $str=$str.'<b>Header:</b><br><textarea name="head" rows="5" style="width:75%">'.ToText($hf[0]).'</textarea><br><br>';
   $str=$str.'<b>List:</b><input type="hidden" name="nE" value="'.$cont[0].'" /><br><input type="submit" name="LET" value="Add item" />&nbsp;&nbsp;<input type="submit" name="LET" value="Add heading" /><br>';
   for($i=0;$i<$cont[0];$i++){
    $item=explode(':�:',$cont[$i+1]);
    if($item[0]=='2')$str=$str.'<br><input type="hidden" name="t'.$i.'" value="2" /><input type="textbox" name="c'.$i.'" style="width:50%" value="'.ToTextSimp($item[1],$page).'" /><br><input type="submit" name="Do'.$i.'" value="Move up"'.(($i==0)?' disabled':'').' />&nbsp;&nbsp;<input type="submit" name="Do'.$i.'" value="Move down"'.(($i==$cont[0]-1)?' disabled':'').' />&nbsp;&nbsp;<input type="submit" name="Do'.$i.'" value="Delete" onClick="return confirm(\'This will delete the listing. continue?\')" /><br>';
    else $str=$str.'<br><input type="hidden" name="t'.$i.'" value="1" />'.ToCodeEdt($fmat,$nms,$item,$i).'<input type="submit" name="Do'.$i.'" value="Move up"'.(($i==0)?' disabled':'').' />&nbsp;&nbsp;<input type="submit" name="Do'.$i.'" value="Move down"'.(($i==$cont[0]-1)?' disabled':'').' />&nbsp;&nbsp;<input type="submit" name="Do'.$i.'" value="Delete" onClick="return confirm(\'This will delete the listing. continue?\')" />&nbsp;&nbsp;<input type="checkbox" name="f'.$i.'" value="Y"'.(($item[0]=='0')?' checked="checked"':'').' id="f'.$i.'" /><label for="f'.$i.'">Hide this item</label><br>';
   }
   if($cont[0]==0)$str=$str.'<br>There are no items in the list.<br>';
   $str=$str.'<br><input type="submit" name="LEB" value="Add item" onClick="document.fm.action=\'?E=Y&S=Y#end\'" />&nbsp;&nbsp;<input type="submit" name="LEB" value="Add heading" onClick="document.fm.action=\'?E=Y&S=Y#end\'" /><br><br><b>Footer:</b><br><textarea name="foot" rows="3" style="width:75%">'.ToText($hf[1]).'</textarea><br>';
  }

  $str=$str.'<img src="img/img.gif" width="12" height="12">&nbsp;<a href="javascript:t=window.open(\'admin/upload.php\',\'upload\',\'width=600,height=500,scrollbars=yes,resizable=yes\');t.focus();LCL()">See avalible pictures / upload new pictures</a><br><img src="img/file.gif" width="12" height="12">&nbsp;<a href="javascript:t=window.open(\'admin/uploadb.php\',\'upload\',\'width=600,height=500,scrollbars=yes,resizable=yes\');t.focus();">See avalible files / upload new files</a><br><input type="submit" title="Click to preview this page" name="do" value="Preview" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" title="Click to save your changes and return to the page" name="do" value="Save" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Cancel" title="Click to return to the page without saving your changes" onClick="if(confirm(\'This will not save your changes. Are you sure you want to cancel?\'))document.location.href=\'?E=N\';return false" /></form><br>';
  $str=$str.'&nbsp;<a name="end">';
  print $strtop.$strteach.$str.$toend;die;
 }
#DISPLAY
 $str=$str.'<a name="Htop"></a><br>';
 if($edt==2)$str=$str.'<span style="font-size:40px;color:#FF6666">PREVIEW</span><br><br>';
 $bn=explode(':�:',$fl[0]);
 if($bn[1]!='')$str=$str.'<span class="Sbanner"'.(($bn[2]=='')?'':' style="font-size:'.$bn[2].'"').'>'.ToCodeBasic($bn[1],$page,'banrLnk',$edt).'</span><br><br>';
 if($sty==1){#LIST
  $hf=explode(':�:',$fl[1]);
  if($hf[0]!='')$str=$str.ToCodeBasic($hf[0],$page,'',$edt).'<br>';
  $nms=explode(':�:',$fl[2]);
  $fmat=substr($fl[3],0,strpos($fl[3],':�:'));
  $cont=explode(':�:',$fl[5]);
  for($i=0;$i<$cont[0];$i++){
   $item=explode(':�:',$cont[$i+1]);
   if($item[0]=='1')$str=$str.'<br><a name="H'.$i.'"></a>'.ToCode($fmat,$nms,$item,$i,$page,$edt);
   elseif($item[0]=='2')$str=$str.'<br><a name="H'.$i.'"></a><b>'.ToCodeBasic($item[1],$page,'',$edt).'</b><br>';
  }
  if($hf[1]!='')$str=$str.'<br>'.ToCodeBasic($hf[1],$page,'',$edt).'<br>';
  $str=$str.'<script language="javascript" type="text/javascript"><!--
DO('.$cont[0].')//--></script>';
#TEXT
 }else{$cont=explode(':�:',$fl[1]);$str=$str.(($cont[1]=='1')?'<b>':'').ToCodeBasic($cont[0],$page,'',$edt).(($cont[1]=='1')?'</b>':'').'<br>';}
 if(strpos($page,'_')!==false){
  $par=substr($page,0,strrpos($page,'_'));
  if($edt)$str=$str.'<br><b><a href="javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\''.$par.'.php\'" onMouseOver="return MO(\'Click to go back\')" onMouseOut="return MO()">BACK</a></b><br>';
  else $str=$str.'<br><b><a href="'.$par.'.php" onMouseOver="return MO(\'Click to go back\')" onMouseOut="return MO()">BACK</a></b><br>';
 }

 print $strtop.$strteach.$str.'&nbsp;<a name="Hend"></a>'.$toend;
}
#FUNCTIONS
function ToCodeEdt($str,$me=array(),$arr=array(),$ind=0){
 $str=str_replace('[[index]]',''.$ind,ToCodeS($str));
 for($i=0;$i<$me[0];$i++)
  if(strpos($str,'[['.$me[$i+1].'=')!==false){
   $st=strpos($str,'[['.$me[$i+1].'=');
   $t=substr($str,$st+strlen($me[$i+1])+3,strpos($str,']]',$st)-$st-strlen($me[$i+1])-3);
   $ln=strlen($t)+strlen($me[$i+1])+5;
   $res='';
   $vls=explode(':',$t);
   switch($vls[0]){
   case'radio':$vlb=explode('"',$vls[3]);for($n=0;$n<$vls[1];$n++)$res=$res.'<input type="radio" name="i'.$i.'_'.$ind.'" value="'.$vlb[$n*4+3].'"'.(($arr[$i+1]==$vlb[$n*4+3])?' checked="checked"':'').' id="i'.$i.'_'.$ind.'_'.$n.'"><label for="i'.$i.'_'.$ind.'_'.$n.'">'.$vlb[$n*4+1].'</label>'.$vls[2];break;
   case'text':$res='<input type="text" name="i'.$i.'_'.$ind.'" value="'.ToTextSimp($arr[$i+1]).'"'.((strpos($vls[1],'%')!==false)?' style="width:'.$vls[1].'"':' size="'.$vls[1].'"').' />';if(isset($vls[2])){if($vls[2]=='img')$res=$res.$vls[3].'<img src="img/img.gif" width="12" height="12">&nbsp;<a href="javascript:t=window.open(\'admin/imgchoose.php\',\'upload\',\'width=600,height=500,scrollbars=yes,resizable=yes\');t.focus();LCL(\'i'.$i.'_'.$ind.'\','.$vls[4].')">Choose</a>';elseif($vls[2]=='file')$res=$res.$vls[3].'<img src="img/file.gif" width="12" height="12">&nbsp;<a href="javascript:t=window.open(\'admin/filechoose.php\',\'upload\',\'width=600,height=500,scrollbars=yes,resizable=yes\');t.focus();LCL(\'i'.$i.'_'.$ind.'\','.$vls[4].')">Choose</a>';}break;
   case'textbox':$res='<textarea name="i'.$i.'_'.$ind.'" rows="'.$vls[2].'"'.((strpos($vls[1],'%')!==false)?' style="width:'.$vls[1].'"':' cols="'.$vls[1].'"').'>'.ToText($arr[$i+1]).'</textarea>';break;
   }
   $str=substr($str,0,$st).$res.substr($str,$st+$ln);
  }
 return $str;
}
function ToCodeBasic($str,$page='',$spcClass='',$alert=0){
 if($spcClass!='')$spcClass=' class="'.$spcClass.'"';
 $str=eregi_replace('\[name\]',$GLOBALS['Teach'],$str);
 $str=eregi_replace('\[email\]','<a href="mailto:'.$GLOBALS['Mail'].'"'.$spcClass.' onMouseOver="return MO(\'Click to e-mail me\')" onMouseOut="return MO()">'.$GLOBALS['Mail'].'</a>',$str);
 $str=eregi_replace('\[emailb\]',$GLOBALS['Mail'],$str);
 $str=eregi_replace('\[telephone\]',$GLOBALS['Tel'],$str);
 $str=eregi_replace('\[address\]',$GLOBALS['Locn'],$str);
 $str=eregi_replace('\[location\]',$GLOBALS['Locn'],$str);
 $str=eregi_replace('\[year\]',date('Y'),$str);

 $str=eregi_replace('([0-9] ?)((st)|(nd)|(rd)|(th))([^a-z])','\\1<sup>\\2</sup>\\7',$str);

 $cnt=1;$x=0;$l=0;$ina=array();$inb=array();$inc=array();$inn=0;$n='';$res='';
 while($cnt){$l=$x;$x=strpos($str,'[',$x);if($x===false)$cnt=0;
  else{$res=$res.substr($str,$l,$x-$l);$n=substr($str,$x+1,strpos($str,']',$x+1)-$x-1);
   if(strlen($n)==0){
    if($inn>0){$inn--;
     if(isset($ina[$inn])){
      if(isset($inc[$inn])){
       if($inc[$inn]==1)$res=substr($res,0,$inb[$inn]).eregi_replace('<li>(<br>&nbsp;)?</li>','','<li>'.eregi_replace('<br>','<br>&nbsp;</li><li>',substr($res,$inb[$inn])).'</li>').$ina[$inn];
      }else $res=$res.$ina[$inn];
    }}$x+=2;
   }else{
    $n2=strtolower($n);
    switch($n2){
    case'r':case'b':case'i':case'u':
    case'red':case'orange':case'yellow':case'green':case'blue':case'indigo':case'violet':
    case'turquoise':case'cyan':case'purple':case'grey':case'white':case'black':
    case'highlight':
     $res=$res.'<span class="UIf'.$n2.'">';$ina[$inn]='</span>';break;
    case'gray':$res=$res.'<span class="UIfgrey">';$ina[$inn]='</span>';break;
    case'regular':$res=$res.'<span class="UIfr">';$ina[$inn]='</span>';break;
    case'bold':$res=$res.'<span class="UIfb">';$ina[$inn]='</span>';break;
    case'italic':$res=$res.'<span class="UIfi">';$ina[$inn]='</span>';break;
    case'underline':$res=$res.'<span class="UIfu">';$ina[$inn]='</span>';break;
    case'x-small':case'very small':$res=$res.'<span class="UIsv">';$ina[$inn]='</span>';break;
    case'small':case'normal':case'large':
     $res=$res.'<span class="UIs'.$n2.'">';$ina[$inn]='</span>';break;
    case'big':$res=$res.'<span class="UIslarge">';$ina[$inn]='</span>';break;
    case'x-large':case'very big':$res=$res.'<span class="UIsb">';$ina[$inn]='</span>';break;
    case'xx-large':case'huge':$res=$res.'<span class="UIsh">';$ina[$inn]='</span>';break;
    case'sub':case'subscript':$res=$res.'<sub>';$ina[$inn]='</sub>';break;
    case'sup':case'superscript':$res=$res.'<sup>';$ina[$inn]='</sup>';break;
    case'left':case'right':case'center':
     $res=$res.'<div align="'.$n2.'">';$ina[$inn]='</div>';break;
    case'middle':$res=$res.'<div align="center">';$ina[$inn]='</div>';break;
    case'list':case'number':$res=$res.'<ol>';$ina[$inn]='</ol>';$inb[$inn]=strlen($res);$inc[$inn]=1;break;
    case'bullet':$res=$res.'<ul>';$ina[$inn]='</ul>';$inb[$inn]=strlen($res);$inc[$inn]=1;break;
    default:
     if(substr($n2,0,1)=='#'){$res=$res.'<span style="color:'.$n2.'">';$ina[$inn]='</span>';
     }elseif(substr($n2,0,5)=='go to'){$tf='';$ts='';$tg='';$mo='';
      if(substr($n2,5)==' top'){$tf='#top';$mo='Click to the top of the page';
      }elseif(substr($n2,5)==' end'){$tf='#end';$mo='Click to the end of the page';
      }elseif(ereg('^ ?[0-9]*$',substr($n,5))){$tf='#';$ts=substr($n2,5);$mo='Click to go to this item';
      }elseif(substr($n2,5,6)==' file:'){$ts=substr($n,11);$tf='files/';$mo='Click to open this file';
      }elseif(substr($n2,5,5)==' url:'){$ts=substr($n,10);$tf='http://';$tg='_blank';$mo='Click to go to this site';
      }elseif(substr($n2,5,6)==' site:'){$ts=substr($n,11);$tf='http://';$tg='_blank';$mo='Click to go to this site';
      }elseif(strpos($n,'.',5)!==false){$ts=substr($n,5);$tf='http://';$tg='_blank';$mo='Click to go to this site';
      }elseif(substr($n2,5,5)==' sub:'){$ts=str_replace('>','_',str_replace(' ','',substr($n,10))).'.php';$tf=$page.'_';$mo='Click to go to this sub page';
      }else{$ts=substr($n,5).'.php';$mo='Click to go to this page';}
      if(substr($ts,0,1)==' ')$ts=substr($ts,1);if(substr($ts,0,6)=='http://')$ts=substr($ts,6);
      $res=$res.'<a href="'.(($alert&&$tg=='')?('javascript:if(confirm(\'Going to this page will not save your changes. Do you want to continue?\'))document.location.href=\''.addslashes($tf.$ts).'\''):$tf.$ts).'"'.$spcClass.(($tg=='')?'':(' target="'.$tg.'"')).' onMouseOver="return MO(\''.$mo.'\')" onMouseOut="return MO()">';$ina[$inn]='</a>';
     }elseif(substr($n2,0,10)=='picture of'){
      $src=substr($n,10);$pos='';$extra='';$cl='';$src=eregi_replace(' (o|i)n the','',$src);
      if(substr($src,-5)==' left'){$src=substr($src,0,strlen($src)-5);$pos=' align="left"';$extra='<div align="left">';$cl='</div>';
      }elseif(substr($src,-6)==' right'){$src=substr($src,0,strlen($src)-6);$pos=' align="right"';$extra='<div align="right">';$cl='</div>';
      }elseif(substr($src,-7)==' center'){$src=substr($src,0,strlen($src)-7);$pos=' align="center"';$extra='<div align="center">';$cl='</div>';
      }elseif(substr($src,-7)==' middle'){$src=substr($src,0,strlen($src)-7);$pos=' align="center"';$extra='<div align="center">';$cl='</div>';}
      if(substr($src,0,1)==' ')$src=substr($src,1);
      if(strpos($src,'.')===false){foreach($GLOBALS['imgext'] as $chk)if(file_exists('cimg/'.$src.'.'.$chk)){$src=$src.'.'.$chk;break;}if(strpos($src,'.')===false)$src='error';}
      if($src=='error')$res=$res.'<img src="img/errpic.gif" border="0"'.$pos.'>'.$extra;
      else $res=$res.'<img src="cimg/'.$src.'" border="0"'.$pos.'>'.$extra;
      if($cl=='')$inn--;
      else $ina[$inn]=$cl;
    }}
    $inn++;
    $x+=strlen($n)+2;
 }}}
 $res=$res.substr($str,$l);
 while($inn>0){$inn--;if(isset($ina[$inn]))$res=$res.$ina[$inn];}
 return eregi_replace('&op;','[',eregi_replace('&cl;',']',$res));
}
function ToTextSimp($str){return str_replace('"','&quot;',$str);}
function ToText($str){return eregi_replace('<br */?>',Chr(10),eregi_replace('<p>',Chr(10).Chr(10),eregi_replace('</p>','',$str)));}
function ToCode($str,$me=array(),$arr=array(),$ind=0,$page,$alert){$str=str_replace('[[index]]',''.$ind,$str);for($i=0;$i<$me[0];$i++){if($arr[$i+1]=='')$str=ereg_replace('\(\('.$me[$i+1].'\)\)\{([^}]*)\}','',$str);else $str=ereg_replace('\(\('.$me[$i+1].'\)\)\{([^}]*)\}','\\1',$str);$str=str_replace('[['.$me[$i+1].']]',ToCodeBasic($arr[$i+1],$page,'',$alert),$str);}$str=ToCodeBasic(ToCodeS($str,$page,'',$alert),$page,'',$alert);return $str;}
function ToCodeS($str){$str=str_replace('[_tbl_det]',' border="[_tbl_border]" cellspacing="[_tbl_space]" cellpadding="[_tbl_pad]" bordercolorlight="[_tbl_light]" bordercolordark="[_tbl_dark]"',$str);
$str=str_replace('[_tbl_border]',	'5',$str);
$str=str_replace('[_tbl_space]',	'1',$str);
$str=str_replace('[_tbl_pad]',	'2',$str);
$str=str_replace('[_tbl_width]',	'70%',$str);
$str=str_replace('[_tbl_back]',	'#FFFFFF',$str);
$str=str_replace('[_tbl_light]',	'#EFECFF',$str);
$str=str_replace('[_tbl_dark]',	'#94A4CC',$str);
return $str;}
function ToSave($str){$str=str_replace(Chr(13),'',$str);$str=str_replace(Chr(10),'<br>',$str);$str=str_replace(':�:',';�;',$str);$str=str_replace(':�:',';�;',$str);return $str;}
?>
