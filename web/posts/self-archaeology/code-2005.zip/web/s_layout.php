<?php
$GLOBALS['above']='../datafiles/';
?>
