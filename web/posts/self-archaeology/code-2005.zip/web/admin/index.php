<?php session_start();?><html><head><title>Teacher login</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css" title="default"><!--
body	{margin:10px;background:#CCCCFF}
a:link	{text-decoration:none;color:#666699}
a:visited	{text-decoration:none;color:#666699}
a:active	{text-decoration:none;color:#9966AA}
a:hover	{text-decoration:underline;color:#6699AA}
--></style></head><?php
$a=false;if(isset($_SESSION['Edit']))if($_SESSION['Edit']=='Y')$a=true;
if($a){$_SESSION['Edit']='N';session_destroy();?>
<body onLoad="setTimeout('document.location.href=\'../<?php if(isset($_SESSION['lsp']))print($_SESSION['lsp'].'.php');?>\'',1000)"><table border="0" cellpadding="0" cellspacing="0"><tr><td width="1" valign="top"><img src="../img/log.gif" width="252" height="246"></td><td width="10"></td><td valign="top" style="font-family:\'arial\',sans-serif;color:#666699"><div style="height:20px"></div><span style="font-size:150%">Logged out</span>
<br><br>
<a href="../<?php if(isset($_SESSION['lsp']))print($_SESSION['lsp'].'.php');?>">If you are not returned automatically, click here to return to the site</a></td></tr></table></body>
<?php }else{$_SESSION['Edit']='Y';
if(isset($_COOKIE['noDelay'])){?>
<body onLoad="setTimeout('document.location.href=\'../<?php if(isset($_SESSION['lsp']))print($_SESSION['lsp'].'.php');?>\'',1000)"><table border="0" cellpadding="0" cellspacing="0"><tr><td width="1" valign="top"><img src="../img/log.gif" width="252" height="246"></td><td width="10"></td><td valign="top" style="font-family:\'arial\',sans-serif;color:#666699"><div style="height:20px"></div><span style="font-size:150%">Logged in</span><br><br>
<a href="../<?php if(isset($_SESSION['lsp']))print($_SESSION['lsp'].'.php');?>">If you are not returned automatically, click here to return to the site</a></td></tr></table></body>
<?php }else{?>
<body><table border="0" cellpadding="0" cellspacing="0"><tr><td width="1" valign="top"><img src="../img/log.gif" width="252" height="246"></td><td width="10"></td><td valign="top" style="font-family:\'arial\',sans-serif;color:#666699"><div style="height:20px"></div><span style="font-size:150%">Logged in</span><br><br>
You are now logged in. Once you return to the site, you will see a <b>"Teacher's Toolbar"</b> at the top of the screen. This toolbar contains all the options you need to edit your pages. If you require more help later, you can click the "Help" button on the toolbar.
<br>
This page will not show again on this computer, instead, you will be logged in and returned to your site immediatly.
<br><br>
<a href="../<?php if(isset($_SESSION['lsp']))print($_SESSION['lsp'].'.php');?>">Click here to begin editing</a></td></tr></table></body>
<?php }}?></html>