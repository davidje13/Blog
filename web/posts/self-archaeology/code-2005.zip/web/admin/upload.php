<html><head><title>Avalible pictures</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css" title="default"><!--
body	{background:#EEEEFF url(../img/imgb.gif) no-repeat fixed;font-family:'arial',sans-serif;color:#000066}
a:link	{text-decoration:none;color:#0000CC}
a:visited	{text-decoration:none;color:#0000CC}
a:active	{text-decoration:none;color:#6600CC}
a:hover	{text-decoration:underline;color:#0066CC}
--></style><meta http-equiv="cache-control" content="no-cache"><meta http-equiv="pragma" content="no-cache"><meta http-equiv="expires" content="0">
</head><body bgcolor="#CCCCFF" leftmargin="8" topmargin="5" rightmargin="8" bottommargin="5" marginwidth="8" marginheight="5">
<?php
session_start();$ok=false;if(isset($_SESSION['Edit']))if($_SESSION['Edit']=='Y')$ok=true;
if(!$ok)print('Sorry, this page is for the teacher only.');else{
if(isset($_GET['d'])){
if($_GET['d']=='del'){
if(strpos($_GET['p'],'..')===false){
unlink('../cimg/'.$_GET['p']);
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Deleted '.$_GET['p'].'</span><br><br>The picture was successfully deleted. Any pages still containing it may appear damaged, so it is recomended that you check the site.</div><br>');
}}
if($_GET['d']=='nma'){
if(strpos($_GET['p'],'..')===false){
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Rename '.$_GET['p'].'</span><br><form name="fn" action="upload.php?d=nmb&p='.$_GET['p'].'" method="post" onSubmit="if(this.nm.value==\'\'){alert(\'No name chosen\');this.nm.focus();return false}return true">Choose a new name: <input type="text" name="nm" size="30" value="'.$_GET['p'].'" /><input type="submit" value="Rename" /><br><span style="font-size:small">Note, if the name is the same as another picture, that image will be replaced</span></form></div><br>');
}}
if($_GET['d']=='nmb'){
if(strpos($_GET['p'],'..')===false){
$det='';
if($_GET['p']==$_POST['nm'])
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Could not rename</span><br>You did not choose a new name</div><br>');
else{
if(file_exists('../cimg/'.$_POST['nm'])&&file_exists('../cimg/'.$_GET['p']))$det='<br>The image has replaced another image. Because of this, some browsers may still display a cached version of the old image. This should not effect your site, but can usually be fixed by closing and re-opening this window.';
copy('../cimg/'.$_GET['p'],'../cimg/'.$_POST['nm']);
unlink('../cimg/'.$_GET['p']);
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Renamed '.$_GET['p'].' to '.$_POST['nm'].'</span>'.$det.'</div><br>');
}}}
}
if(isset($_POST['Has'])){
if(move_uploaded_file($_FILES['toUpload']['tmp_name'],'../cimg/'.$_FILES['toUpload']['name'])){
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Uploaded</span><br>Your image was uploaded successfully. To include it in pages, use this text:<br><b>[picture of '.$_FILES['toUpload']['name'].']</b></div><br>');
}else{switch($_FILES['toUpload']['error']){
case 1:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it is too big. Try using a different format, such as .gif .jpg or .png</div><br>');break;
case 2:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it is too big. Try using a different format, such as .jpg .gif or .png</div><br>');break;
case 3:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>There was a problem while uploading your picture. You may have been cut off from the internet, or the file may be damaged. Try uploading it again. If it continues to fail, consider converting it to a .gif .jpg or .png file</div><br>');break;
case 4:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it was not found. Please try again.</div><br>');break;
default:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br><br>There was an unknown error while uploading your picture.</div><br>');
}}}
?><span style="font-size:large">Upload a new picture</span><br>
<form name="fm" action="upload.php" method="post" enctype="multipart/form-data" onSubmit="if(this.toUpload.value==''){alert('No image selected');this.toUpload.focus();return false}this.sm.disabled=true;this.sm.value='UPLOADING - PLEASE WAIT';return true">Choose the picture to upload: <input type="hidden" name="Has" value="1" /><input type="hidden" name="MAX_FILE_SIZE" value="70000" /><input type="file" name="toUpload" />
<br><span style="font-size:small">Note, this is for uploading pictures only</span>
<br><input type="submit" name="sm" value="Upload now" /></form><br>
<span style="font-size:large">Pictures</span><br><?php
$none=true;$dp=opendir('../cimg/');$wd=5;$ht=0;$at=$wd;$ar=array();$maxW=100;$maxH=70;

while($item=readdir($dp))if(is_file('../cimg/'.$item)){
if($at>=$wd){$at=0;$ar[$ht]=array(0);$ht++;}
$ar[$ht-1][$at+1]=$item;$ar[$ht-1][0]++;$at++;}
if($ht==0)print('<i>none</i><br>');
else{print('<table width="100%" heigt="100%" border="0" cellpadding="0" cellspacing="0">');
foreach($ar as $itm){print('<tr>');
for($i=0;$i<$itm[0];$i++){$s=getimagesize('../cimg/'.$itm[$i+1]);
if($s[0]>$maxW){$s[1]=($s[1]*$maxW)/$s[0];$s[0]=$maxW;}
if($s[1]>$maxH){$s[0]=($s[0]*$maxH)/$s[1];$s[1]=$maxH;}
print('<td align="center"><img src="../cimg/'.$itm[$i+1].'" border="0" width="'.ceil($s[0]).'" height="'.ceil($s[1]).'"></td>');}
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr>');
for($i=0;$i<$itm[0];$i++)print('<td align="center" valign="top">(&nbsp;'.$itm[$i+1].'&nbsp;)<br><a href="javascript:if(confirm(\'This will delete the picture. Are you sure?\'))document.location.href=\'upload.php?d=del&p='.$itm[$i+1].'\'">Delete</a><br><a href="upload.php?d=nma&p='.$itm[$i+1].'">Rename</a></td>');
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr><td height="5" colspan="'.$wd.'"></td>');
print('</tr>');}print('</table><br><a href="javascript:window.close()" title="Close this window">CLOSE</a>');}}
?></body></html>