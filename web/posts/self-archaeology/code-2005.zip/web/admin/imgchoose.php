<html><head><title>Avalible pictures</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css" title="default"><!--
body	{background:#EEEEFF url(../img/imgb.gif) no-repeat fixed;font-family:'arial',sans-serif;color:#000066}
a:link	{text-decoration:none;color:#0000CC}
a:visited	{text-decoration:none;color:#0000CC}
a:active	{text-decoration:none;color:#6600CC}
a:hover	{text-decoration:underline;color:#0066CC}
--></style><meta http-equiv="cache-control" content="no-cache"><meta http-equiv="pragma" content="no-cache"><meta http-equiv="expires" content="0">
</head><body bgcolor="#CCCCFF" leftmargin="8" topmargin="5" rightmargin="8" bottommargin="5" marginwidth="8" marginheight="5">
<?php
session_start();$ok=false;if(isset($_SESSION['Edit']))if($_SESSION['Edit']=='Y')$ok=true;
if(!$ok)print('Sorry, this page is for the teacher only.');else{

if(isset($_POST['Has'])){
if(move_uploaded_file($_FILES['toUpload']['tmp_name'],'../cimg/'.$_FILES['toUpload']['name'])){
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Uploaded</span><br>Your image was uploaded successfully.<br><a href="javascript:window.opener.setTimeout(\'DI(\\\''.$_FILES['toUpload']['name'].'\\\')\',0);window.close()" title="Click to add this image">Click here to use it</a></div><br>');
}else{switch($_FILES['toUpload']['error']){
case 1:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it is too big. Try using a different format, such as .gif .jpg or .png</div><br>');break;
case 2:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it is too big. Try using a different format, such as .jpg .gif or .png</div><br>');break;
case 3:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>There was a problem while uploading your picture. You may have been cut off from the internet, or the file may be damaged. Try uploading it again. If it continues to fail, consider converting it to a .gif .jpg or .png file</div><br>');break;
case 4:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br>Your image could not be uploaded because it was not found. Please try again.</div><br>');break;
default:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:x-large">Failed</span><br><br>There was an unknown error while uploading your picture.</div><br>');
}}}
?><span style="font-size:large">Upload a new picture</span><br>
<form name="fm" action="imgchoose.php" method="post" enctype="multipart/form-data" onSubmit="if(this.toUpload.value==''){alert('No image selected');this.toUpload.focus();return false}this.sm.disabled=true;this.sm.value='UPLOADING - PLEASE WAIT';return true">Choose the picture to upload: <input type="hidden" name="Has" value="1" /><input type="hidden" name="MAX_FILE_SIZE" value="70000" /><input type="file" name="toUpload" />
<br><span style="font-size:small">Note, this is for uploading pictures only</span>
<br><input type="submit" name="sm" value="Upload now" /></form><br>
<span style="font-size:large">Choose picture</span><br>
<a href="upload.php" title="Picture organiser">To organise these pictures, go here</a><br><?php
$none=true;$dp=opendir('../cimg/');$wd=5;$ht=0;$at=$wd;$ar=array();$maxW=100;$maxH=100;

while($item=readdir($dp))if(is_file('../cimg/'.$item)){
if($at>=$wd){$at=0;$ar[$ht]=array(0);$ht++;}
$ar[$ht-1][$at+1]=$item;$ar[$ht-1][0]++;$at++;}
if($ht==0)print('<i>there are no pictures avalible</i><br>');
else{print('<table width="100%" heigt="100%" border="0" cellpadding="0" cellspacing="0">');
foreach($ar as $itm){print('<tr>');
for($i=0;$i<$itm[0];$i++){$s=getimagesize('../cimg/'.$itm[$i+1]);
if($s[0]>$maxW){$s[1]=($s[1]*$maxW)/$s[0];$s[0]=$maxW;}
if($s[1]>$maxH){$s[0]=($s[0]*$maxH)/$s[1];$s[1]=$maxH;}
print('<td align="center"><a href="javascript:window.opener.setTimeout(\'DI(\\\''.$itm[$i+1].'\\\')\',0);window.close()" title="Click to use this image"><img src="../cimg/'.$itm[$i+1].'" border="0" width="'.ceil($s[0]).'" height="'.ceil($s[1]).'"></a></td>');}
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr>');
for($i=0;$i<$itm[0];$i++)print('<td align="center" valign="top">(&nbsp;'.$itm[$i+1].'&nbsp;)<br><a href="javascript:window.opener.setTimeout(\'DI(\\\''.$itm[$i+1].'\\\')\',0);window.close()" title="Click to use this image">Choose</a></td>');
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr><td height="5" colspan="'.$wd.'"></td>');
print('</tr>');}print('</table><br><a href="javascript:window.close()" title="Click to return without choosing an image">CANCEL</a>');}}
?></body></html>