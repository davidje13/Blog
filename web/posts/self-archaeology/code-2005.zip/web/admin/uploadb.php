<html><head><title>Avalible pictures</title><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><style type="text/css" title="default"><!--
body	{background:#EEEEFF url(../img/fileb.gif) no-repeat fixed;font-family:'arial',sans-serif;color:#000066}
a:link	{text-decoration:none;color:#0000CC}
a:visited	{text-decoration:none;color:#0000CC}
a:active	{text-decoration:none;color:#6600CC}
a:hover	{text-decoration:underline;color:#0066CC}
--></style><meta http-equiv="cache-control" content="no-cache"><meta http-equiv="pragma" content="no-cache"><meta http-equiv="expires" content="0">
</head><body bgcolor="#CCCCFF" leftmargin="8" topmargin="5" rightmargin="8" bottommargin="5" marginwidth="8" marginheight="5">
<?php
session_start();$ok=false;if(isset($_SESSION['Edit']))if($_SESSION['Edit']=='Y')$ok=true;
if(!$ok)print('Sorry, this page is for the teacher only.');else{
if(isset($_GET['d'])){
if($_GET['d']=='del'){
if(strpos($_GET['p'],'..')===false){
unlink('../files/'.$_GET['p']);
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Deleted '.$_GET['p'].'</span><br>The file was successfully deleted.</div><br>');
}}
if($_GET['d']=='nma'){
if(strpos($_GET['p'],'..')===false){
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Rename '.$_GET['p'].'</span><br><form name="fn" action="uploadb.php?d=nmb&p='.$_GET['p'].'" method="post">Choose a new name: <input type="text" name="nm" size="30" value="'.$_GET['p'].'" /><input type="submit" value="Rename" onClick="if(document.fn.nm.value==\'\'){alert(\'No name chosen\');document.fn.nm.focus();return false}return true" /><br><span style="font-size:small">Note, if the name is the same as another file, that file will be replaced</span></form></div><br>');
}}
if($_GET['d']=='nmb'){
if(strpos($_GET['p'],'..')===false){
$det='';
if($_GET['p']==$_POST['nm'])
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Could not rename</span><br>You did not choose a new name</div><br>');
else{
if(file_exists('../files/'.$_POST['nm'])&&file_exists('../files/'.$_GET['p']))$det='<br>The file has replaced another file.';
copy('../files/'.$_GET['p'],'../files/'.$_POST['nm']);
unlink('../files/'.$_GET['p']);
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Renamed '.$_GET['p'].' to '.$_POST['nm'].'</span>'.$det.'</div><br>');
}}}
}
if(isset($_POST['Has'])){
if(move_uploaded_file($_FILES['toUpload']['tmp_name'],'../files/'.$_FILES['toUpload']['name'])){
print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Uploaded</span><br><br>Your file was uploaded successfully. You can now reference it with this:<br><b>[go to file:'.$_FILES['toUpload']['name'].']<i>link text</i>[]</b></div><br>');
}else{switch($_FILES['toUpload']['error']){
case 1:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Failed</span><br><br>Your file could not be uploaded because it is too big.</div><br>');break;
case 2:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Failed</span><br><br>Your file could not be uploaded because it is too big.</div><br>');break;
case 3:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Failed</span><br><br>There was a problem while uploading your file. You may have been cut off from the internet, or the file may be damaged. Try uploading it again.</div><br>');break;
case 4:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Failed</span><br><br>Your file could not be uploaded because it was not found. Please try again.</div><br>');break;
default:print('<div style="background-color:#C3C3FF;padding:5px;"><span style="font-size:large">Failed</span><br><br>There was an unknown error while uploading your file.</div><br>');
}}}
?><span style="font-size:large">Upload a new file</span><br>
<form name="fm" action="uploadb.php" method="post" enctype="multipart/form-data" onSubmit="if(this.toUpload.value==''){alert('No file selected');this.toUpload.focus();return false}this.sm.disabled=true;this.sm.value='UPLOADING - PLEASE WAIT';return true">Choose the file to upload: <input type="hidden" name="Has" value="1" /><input type="hidden" name="MAX_FILE_SIZE" value="200000" /><input type="file" name="toUpload" />
<br><span style="font-size:small">Note, this should not be used to upload pictures</span>
<br><input type="submit" name="sm" value="Upload now" /></form><br>
<span style="font-size:large">Avalible files</span><br><?php
$none=true;$dp=opendir('../files/');$wd=5;$ht=0;$at=$wd;$ar=array();

while($item=readdir($dp))if(is_file('../files/'.$item)){
if($at>=$wd){$at=0;$ar[$ht]=array(0);$ht++;}
$ar[$ht-1][$at+1]=$item;$ar[$ht-1][0]++;$at++;}
if($ht==0)print('<i>none</i><br>');
else{print('<table width="100%" heigt="100%" border="0" cellpadding="0" cellspacing="0">');
foreach($ar as $itm){print('<tr>');
for($i=0;$i<$itm[0];$i++){
print('<td align="center"><img src="../img/ficon.gif" border="0"></td>');}
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr>');
for($i=0;$i<$itm[0];$i++)print('<td align="center" valign="top">(&nbsp;'.$itm[$i+1].'&nbsp;)<br><a href="javascript:if(confirm(\'This will delete the file. Are you sure?\'))document.location.href=\'uploadb.php?d=del&p='.$itm[$i+1].'\'">Delete</a><br><a href="uploadb.php?d=nma&p='.$itm[$i+1].'">Rename</a></td>');
for($i=$itm[0];$i<$wd;$i++)print('<td></td>');
print('</tr><tr><td height="5" colspan="'.$wd.'"></td>');
print('</tr>');}print('</table><br><a href="javascript:window.close()" title="Close this window">CLOSE</a>');}}
?></body></html>